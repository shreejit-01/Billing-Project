﻿using BillingSystemMotorRewinding.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BillingSystemMotorRewinding
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void newInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewInvoice v = new NewInvoice();
            v.Show();
        }

        private void storeDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StoreDetails sd = new StoreDetails();
            sd.Show();
        }

        private void newDCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewDC nd = new NewDC();
            nd.Show();
        }

        private void invoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewInvoiceToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewDCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewDC vd = new ViewDC();
            vd.Show();
        }
    }
}
