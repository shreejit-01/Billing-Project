﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BillingSystemMotorRewinding.UI
{
    public partial class ViewDC : Form
    {
        public ViewDC()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'billingSystemDataSet.DC_item' table. You can move, or remove it, as needed.
            this.dC_itemTableAdapter.Fill(this.billingSystemDataSet.DC_item);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.dC_itemTableAdapter.FillBy(this.billingSystemDataSet.DC_item);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
