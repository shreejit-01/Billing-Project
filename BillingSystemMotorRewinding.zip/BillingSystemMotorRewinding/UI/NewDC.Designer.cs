﻿namespace BillingSystemMotorRewinding.UI
{
    partial class NewDC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.iN_itemTableAdapter = new BillingSystemMotorRewinding.BillingSystemDataSetTableAdapters.IN_itemTableAdapter();
            this.iNitemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.billingSystemDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.billingSystemDataSet = new BillingSystemMotorRewinding.BillingSystemDataSet();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCnoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remarkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dCitemBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.iN_DetailsTableAdapter = new BillingSystemMotorRewinding.BillingSystemDataSetTableAdapters.IN_DetailsTableAdapter();
            this.iNDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dCitemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dC_itemTableAdapter = new BillingSystemMotorRewinding.BillingSystemDataSetTableAdapters.DC_itemTableAdapter();
            this.clientDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.client_DetailsTableAdapter = new BillingSystemMotorRewinding.BillingSystemDataSetTableAdapters.Client_DetailsTableAdapter();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.iNitemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingSystemDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingSystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dCitemBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dCitemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientDetailsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // iN_itemTableAdapter
            // 
            this.iN_itemTableAdapter.ClearBeforeFill = true;
            // 
            // iNitemBindingSource
            // 
            this.iNitemBindingSource.DataMember = "IN_item";
            this.iNitemBindingSource.DataSource = this.billingSystemDataSetBindingSource;
            // 
            // billingSystemDataSetBindingSource
            // 
            this.billingSystemDataSetBindingSource.DataSource = this.billingSystemDataSet;
            this.billingSystemDataSetBindingSource.Position = 0;
            // 
            // billingSystemDataSet
            // 
            this.billingSystemDataSet.DataSetName = "BillingSystemDataSet";
            this.billingSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.dCnoDataGridViewTextBoxColumn,
            this.itemDataGridViewTextBoxColumn,
            this.remarkDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.dCitemBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(36, 231);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(771, 212);
            this.dataGridView1.TabIndex = 40;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Width = 125;
            // 
            // dCnoDataGridViewTextBoxColumn
            // 
            this.dCnoDataGridViewTextBoxColumn.DataPropertyName = "DCno";
            this.dCnoDataGridViewTextBoxColumn.HeaderText = "DCno";
            this.dCnoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dCnoDataGridViewTextBoxColumn.Name = "dCnoDataGridViewTextBoxColumn";
            this.dCnoDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemDataGridViewTextBoxColumn
            // 
            this.itemDataGridViewTextBoxColumn.DataPropertyName = "item";
            this.itemDataGridViewTextBoxColumn.HeaderText = "item";
            this.itemDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.itemDataGridViewTextBoxColumn.Name = "itemDataGridViewTextBoxColumn";
            this.itemDataGridViewTextBoxColumn.Width = 125;
            // 
            // remarkDataGridViewTextBoxColumn
            // 
            this.remarkDataGridViewTextBoxColumn.DataPropertyName = "remark";
            this.remarkDataGridViewTextBoxColumn.HeaderText = "remark";
            this.remarkDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.remarkDataGridViewTextBoxColumn.Name = "remarkDataGridViewTextBoxColumn";
            this.remarkDataGridViewTextBoxColumn.Width = 125;
            // 
            // dCitemBindingSource1
            // 
            this.dCitemBindingSource1.DataMember = "DC_item";
            this.dCitemBindingSource1.DataSource = this.billingSystemDataSetBindingSource;
            // 
            // iN_DetailsTableAdapter
            // 
            this.iN_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // iNDetailsBindingSource
            // 
            this.iNDetailsBindingSource.DataMember = "IN_Details";
            this.iNDetailsBindingSource.DataSource = this.billingSystemDataSet;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.richTextBox1.Location = new System.Drawing.Point(194, 118);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(270, 85);
            this.richTextBox1.TabIndex = 39;
            this.richTextBox1.Text = "";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(194, 81);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(270, 22);
            this.textBox6.TabIndex = 36;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(837, 14);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(281, 22);
            this.textBox2.TabIndex = 32;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(194, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(270, 22);
            this.textBox1.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 17);
            this.label7.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(721, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 17);
            this.label8.TabIndex = 27;
            this.label8.Text = "Client DC Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(721, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 17);
            this.label5.TabIndex = 26;
            this.label5.Text = "Client DC no";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 17);
            this.label3.TabIndex = 24;
            this.label3.Text = "Client Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 17);
            this.label4.TabIndex = 23;
            this.label4.Text = "Client Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 22;
            this.label2.Text = "DC date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "DC no.";
            // 
            // dCitemBindingSource
            // 
            this.dCitemBindingSource.DataMember = "DC_item";
            this.dCitemBindingSource.DataSource = this.billingSystemDataSetBindingSource;
            // 
            // dC_itemTableAdapter
            // 
            this.dC_itemTableAdapter.ClearBeforeFill = true;
            // 
            // clientDetailsBindingSource
            // 
            this.clientDetailsBindingSource.DataMember = "Client_Details";
            this.clientDetailsBindingSource.DataSource = this.billingSystemDataSetBindingSource;
            // 
            // client_DetailsTableAdapter
            // 
            this.client_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(194, 44);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(270, 22);
            this.dateTimePicker1.TabIndex = 41;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(837, 45);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(281, 22);
            this.dateTimePicker2.TabIndex = 42;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(1063, 336);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 44);
            this.button1.TabIndex = 43;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(1063, 399);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(151, 44);
            this.button2.TabIndex = 44;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // NewDC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1243, 463);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "NewDC";
            this.Text = "New Delivery Challan";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.iNitemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingSystemDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingSystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dCitemBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iNDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dCitemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientDetailsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private BillingSystemDataSetTableAdapters.IN_itemTableAdapter iN_itemTableAdapter;
        private System.Windows.Forms.BindingSource iNitemBindingSource;
        private System.Windows.Forms.BindingSource billingSystemDataSetBindingSource;
        private BillingSystemDataSet billingSystemDataSet;
        private System.Windows.Forms.DataGridView dataGridView1;
        private BillingSystemDataSetTableAdapters.IN_DetailsTableAdapter iN_DetailsTableAdapter;
        private System.Windows.Forms.BindingSource iNDetailsBindingSource;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource dCitemBindingSource;
        private BillingSystemDataSetTableAdapters.DC_itemTableAdapter dC_itemTableAdapter;
        private System.Windows.Forms.BindingSource clientDetailsBindingSource;
        private BillingSystemDataSetTableAdapters.Client_DetailsTableAdapter client_DetailsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dCnoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn remarkDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dCitemBindingSource1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}