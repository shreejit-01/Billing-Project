﻿namespace BillingSystemMotorRewinding.UI
{
    partial class ViewDC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dCitemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.billingSystemDataSet = new BillingSystemMotorRewinding.BillingSystemDataSet();
            this.dC_itemTableAdapter = new BillingSystemMotorRewinding.BillingSystemDataSetTableAdapters.DC_itemTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dCitemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingSystemDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "DC no:-";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(76, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(242, 22);
            this.textBox1.TabIndex = 1;
            // 
            // dCitemBindingSource
            // 
            this.dCitemBindingSource.DataMember = "DC_item";
            this.dCitemBindingSource.DataSource = this.billingSystemDataSet;
            // 
            // billingSystemDataSet
            // 
            this.billingSystemDataSet.DataSetName = "BillingSystemDataSet";
            this.billingSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dC_itemTableAdapter
            // 
            this.dC_itemTableAdapter.ClearBeforeFill = true;
            // 
            // ViewDC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "ViewDC";
            this.Text = "View Delivery Chalan";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dCitemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingSystemDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private BillingSystemDataSet billingSystemDataSet;
        private System.Windows.Forms.BindingSource dCitemBindingSource;
        private BillingSystemDataSetTableAdapters.DC_itemTableAdapter dC_itemTableAdapter;
    }
}