﻿namespace BillingSystemMotorRewinding
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.invoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editInvoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deliveryChallanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newClientRegisteryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storeDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.invoiceToolStripMenuItem,
            this.deliveryChallanToolStripMenuItem,
            this.clientDetailsToolStripMenuItem,
            this.storeDetailsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1051, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // invoiceToolStripMenuItem
            // 
            this.invoiceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newInvoiceToolStripMenuItem,
            this.viewInvoiceToolStripMenuItem,
            this.searchInvoiceToolStripMenuItem,
            this.deleteInvoiceToolStripMenuItem,
            this.editInvoiceToolStripMenuItem});
            this.invoiceToolStripMenuItem.Name = "invoiceToolStripMenuItem";
            this.invoiceToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.invoiceToolStripMenuItem.Text = "Invoice";
            this.invoiceToolStripMenuItem.Click += new System.EventHandler(this.invoiceToolStripMenuItem_Click);
            // 
            // newInvoiceToolStripMenuItem
            // 
            this.newInvoiceToolStripMenuItem.Name = "newInvoiceToolStripMenuItem";
            this.newInvoiceToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.newInvoiceToolStripMenuItem.Text = "New Invoice";
            this.newInvoiceToolStripMenuItem.Click += new System.EventHandler(this.newInvoiceToolStripMenuItem_Click);
            // 
            // viewInvoiceToolStripMenuItem
            // 
            this.viewInvoiceToolStripMenuItem.Name = "viewInvoiceToolStripMenuItem";
            this.viewInvoiceToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.viewInvoiceToolStripMenuItem.Text = "View Invoice";
            this.viewInvoiceToolStripMenuItem.Click += new System.EventHandler(this.viewInvoiceToolStripMenuItem_Click);
            // 
            // searchInvoiceToolStripMenuItem
            // 
            this.searchInvoiceToolStripMenuItem.Name = "searchInvoiceToolStripMenuItem";
            this.searchInvoiceToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.searchInvoiceToolStripMenuItem.Text = "Search Invoice";
            // 
            // deleteInvoiceToolStripMenuItem
            // 
            this.deleteInvoiceToolStripMenuItem.Name = "deleteInvoiceToolStripMenuItem";
            this.deleteInvoiceToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.deleteInvoiceToolStripMenuItem.Text = "Delete Invoice";
            // 
            // editInvoiceToolStripMenuItem
            // 
            this.editInvoiceToolStripMenuItem.Name = "editInvoiceToolStripMenuItem";
            this.editInvoiceToolStripMenuItem.Size = new System.Drawing.Size(187, 26);
            this.editInvoiceToolStripMenuItem.Text = "Edit Invoice";
            // 
            // deliveryChallanToolStripMenuItem
            // 
            this.deliveryChallanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newDCToolStripMenuItem,
            this.editDCToolStripMenuItem,
            this.searchDCToolStripMenuItem,
            this.deleteDCToolStripMenuItem,
            this.viewDCToolStripMenuItem});
            this.deliveryChallanToolStripMenuItem.Name = "deliveryChallanToolStripMenuItem";
            this.deliveryChallanToolStripMenuItem.Size = new System.Drawing.Size(130, 24);
            this.deliveryChallanToolStripMenuItem.Text = "Delivery Challan";
            // 
            // newDCToolStripMenuItem
            // 
            this.newDCToolStripMenuItem.Name = "newDCToolStripMenuItem";
            this.newDCToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.newDCToolStripMenuItem.Text = "New D.C";
            this.newDCToolStripMenuItem.Click += new System.EventHandler(this.newDCToolStripMenuItem_Click);
            // 
            // editDCToolStripMenuItem
            // 
            this.editDCToolStripMenuItem.Name = "editDCToolStripMenuItem";
            this.editDCToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.editDCToolStripMenuItem.Text = "Edit D.C";
            // 
            // searchDCToolStripMenuItem
            // 
            this.searchDCToolStripMenuItem.Name = "searchDCToolStripMenuItem";
            this.searchDCToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.searchDCToolStripMenuItem.Text = "Search D.C";
            // 
            // deleteDCToolStripMenuItem
            // 
            this.deleteDCToolStripMenuItem.Name = "deleteDCToolStripMenuItem";
            this.deleteDCToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.deleteDCToolStripMenuItem.Text = "Delete D.C";
            // 
            // viewDCToolStripMenuItem
            // 
            this.viewDCToolStripMenuItem.Name = "viewDCToolStripMenuItem";
            this.viewDCToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.viewDCToolStripMenuItem.Text = "View D.C";
            this.viewDCToolStripMenuItem.Click += new System.EventHandler(this.viewDCToolStripMenuItem_Click);
            // 
            // clientDetailsToolStripMenuItem
            // 
            this.clientDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newClientRegisteryToolStripMenuItem,
            this.searchClientToolStripMenuItem,
            this.editDetailsToolStripMenuItem,
            this.deleteClientToolStripMenuItem,
            this.viewClientToolStripMenuItem});
            this.clientDetailsToolStripMenuItem.Name = "clientDetailsToolStripMenuItem";
            this.clientDetailsToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.clientDetailsToolStripMenuItem.Text = "Client Details";
            // 
            // newClientRegisteryToolStripMenuItem
            // 
            this.newClientRegisteryToolStripMenuItem.Name = "newClientRegisteryToolStripMenuItem";
            this.newClientRegisteryToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.newClientRegisteryToolStripMenuItem.Text = "New Client Registery";
            // 
            // searchClientToolStripMenuItem
            // 
            this.searchClientToolStripMenuItem.Name = "searchClientToolStripMenuItem";
            this.searchClientToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.searchClientToolStripMenuItem.Text = "Search Client";
            // 
            // editDetailsToolStripMenuItem
            // 
            this.editDetailsToolStripMenuItem.Name = "editDetailsToolStripMenuItem";
            this.editDetailsToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.editDetailsToolStripMenuItem.Text = "Edit Details";
            // 
            // deleteClientToolStripMenuItem
            // 
            this.deleteClientToolStripMenuItem.Name = "deleteClientToolStripMenuItem";
            this.deleteClientToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.deleteClientToolStripMenuItem.Text = "Delete Client";
            // 
            // viewClientToolStripMenuItem
            // 
            this.viewClientToolStripMenuItem.Name = "viewClientToolStripMenuItem";
            this.viewClientToolStripMenuItem.Size = new System.Drawing.Size(229, 26);
            this.viewClientToolStripMenuItem.Text = "View Client";
            // 
            // storeDetailsToolStripMenuItem
            // 
            this.storeDetailsToolStripMenuItem.Name = "storeDetailsToolStripMenuItem";
            this.storeDetailsToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.storeDetailsToolStripMenuItem.Text = "Store Details";
            this.storeDetailsToolStripMenuItem.Click += new System.EventHandler(this.storeDetailsToolStripMenuItem_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 524);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem invoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editInvoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deliveryChallanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newClientRegisteryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storeDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewClientToolStripMenuItem;
    }
}

