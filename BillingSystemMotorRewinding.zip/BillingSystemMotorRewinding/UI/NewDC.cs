﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BillingSystemMotorRewinding.UI
{
    public partial class NewDC : Form
    {
        public NewDC()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'billingSystemDataSet.Client_Details' table. You can move, or remove it, as needed.
            this.client_DetailsTableAdapter.Fill(this.billingSystemDataSet.Client_Details);
            // TODO: This line of code loads data into the 'billingSystemDataSet.DC_item' table. You can move, or remove it, as needed.
            this.dC_itemTableAdapter.Fill(this.billingSystemDataSet.DC_item);

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
