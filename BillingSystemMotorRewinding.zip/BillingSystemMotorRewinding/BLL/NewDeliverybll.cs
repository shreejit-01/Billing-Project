﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BillingSystemMotorRewinding.BLL
{
    class NewDeliverybll
    {
        public int Id { get; set; }
        public String Cname { get; set; }
        public int DCno { get; set; }
        public int POno { get; set; }
        public int CDCno { get; set; }
        public int DCvno { get; set; }
        public DateTime DCdate { get; set; }
        public DateTime CDCdate { get; set; }
        public DateTime POdate { get; set; }


    }
}
